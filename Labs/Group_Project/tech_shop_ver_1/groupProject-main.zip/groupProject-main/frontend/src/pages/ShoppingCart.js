import React from "react";

function ShoppingCart() {
  return <div>ShoppingCart</div>;
}

export default ShoppingCart;
